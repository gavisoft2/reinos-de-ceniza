const canvas=document.getElementById('world');
const ctx=canvas.getContext('2d');

const state={level:1,hp:100,gold:0,wood:0,stone:0,copper:0,iron:0,fish:0};
const player={x:500,y:350,r:14,speed:3.2};
const keys={};
let last=0;

const world={w:1800,h:1200};
const trees=[{x:250,y:260},{x:340,y:180},{x:470,y:250},{x:1400,y:250},{x:1510,y:340},{x:1300,y:430},{x:280,y:850},{x:410,y:930},{x:1500,y:850}];
const rocks=[{x:720,y:220,type:'copper'},{x:820,y:300,type:'iron'},{x:950,y:180,type:'stone'},{x:1080,y:270,type:'copper'},{x:1200,y:190,type:'iron'}];
const fishSpots=[{x:350,y:520},{x:500,y:540},{x:650,y:500},{x:1420,y:620}];
const mobs=[{x:900,y:650,hp:30,max:30,name:'Lobo'},{x:1040,y:760,hp:45,max:45,name:'Jabalí'},{x:1220,y:680,hp:60,max:60,name:'Goblin'}];

function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}
addEventListener('resize',resize); resize();

addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true; keys[e.key]=true});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false; keys[e.key]=false});

document.querySelectorAll('button[data-key]').forEach(b=>{
  const k=b.dataset.key;
  b.addEventListener('pointerdown',e=>{e.preventDefault();keys[k]=true});
  b.addEventListener('pointerup',()=>keys[k]=false);
  b.addEventListener('pointercancel',()=>keys[k]=false);
  b.addEventListener('pointerleave',()=>keys[k]=false);
});

function near(a,b,d=45){return Math.hypot(a.x-b.x,a.y-b.y)<d}
function msg(t){document.getElementById('message').textContent=t}

function interact(){
  for(const t of trees) if(near(player,t,42)){state.wood++; msg('🪓 Talaste un árbol: +1 madera'); return}
  for(const r of rocks) if(near(player,r,42)){
    if(r.type==='copper') state.copper++;
    else if(r.type==='iron') state.iron++;
    else state.stone++;
    msg('⛏️ Minería: +1 '+(r.type==='copper'?'cobre':r.type==='iron'?'hierro':'piedra')); return
  }
  for(const f of fishSpots) if(near(player,f,48)){state.fish++; msg('🎣 Pescaste: +1 pez'); return}
  for(const m of mobs) if(m.hp>0 && near(player,m,48)){
    m.hp-=15;
    if(m.hp<=0){state.gold+=10;state.level=Math.min(99,state.level+1);msg('⚔️ '+m.name+' derrotado: +10 oro y +1 nivel')}
    else msg('⚔️ Golpeaste al '+m.name+' (-15 HP)');
    return
  }
}

addEventListener('keydown',e=>{if(e.key===' '||e.key==='e'||e.key==='E'){interact();e.preventDefault()}});

function drawWorld(camX,camY){
  ctx.fillStyle='#4d8a49';ctx.fillRect(0,0,innerWidth,innerHeight);

  // water
  ctx.fillStyle='#2d72a8';
  ctx.fillRect(-camX,480-camY,760,190);
  ctx.fillRect(1260-camX,540-camY,540,180);

  // roads
  ctx.fillStyle='#b99b67';ctx.fillRect(-camX,600-camY,1800,55);

  for(const t of trees){
    const x=t.x-camX,y=t.y-camY;
    ctx.fillStyle='#65432d';ctx.fillRect(x-5,y+8,10,22);
    ctx.fillStyle='#246b32';ctx.beginPath();ctx.arc(x,y,25,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#34853f';ctx.beginPath();ctx.arc(x-12,y-8,15,0,Math.PI*2);ctx.fill();
  }

  for(const r of rocks){
    const x=r.x-camX,y=r.y-camY;
    ctx.fillStyle=r.type==='copper'?'#a76538':r.type==='iron'?'#6f747b':'#888';
    ctx.beginPath();ctx.arc(x,y,22,0,Math.PI*2);ctx.fill();
    ctx.fillStyle='#fff';ctx.font='11px Arial';ctx.textAlign='center';ctx.fillText(r.type==='copper'?'Cobre':r.type==='iron'?'Hierro':'Piedra',x,y+4);
  }

  for(const f of fishSpots){
    const x=f.x-camX,y=f.y-camY;ctx.fillStyle='#dcefff';ctx.font='22px Arial';ctx.fillText('🐟',x,y);
  }

  for(const m of mobs){
    if(m.hp<=0)continue;
    const x=m.x-camX,y=m.y-camY;
    ctx.font='28px Arial';ctx.textAlign='center';ctx.fillText(m.name==='Lobo'?'🐺':m.name==='Jabalí'?'🐗':'👹',x,y);
    ctx.fillStyle='#222';ctx.fillRect(x-22,y-32,44,5);ctx.fillStyle='#e44';ctx.fillRect(x-22,y-32,44*(m.hp/m.max),5);
  }

  const px=player.x-camX,py=player.y-camY;
  ctx.font='30px Arial';ctx.textAlign='center';ctx.fillText('🧙',px,py+10);
}

function update(t){
  const dt=Math.min(32,t-last||16);last=t;
  let dx=0,dy=0;
  if(keys['w']||keys['ArrowUp'])dy-=1;
  if(keys['s']||keys['ArrowDown'])dy+=1;
  if(keys['a']||keys['ArrowLeft'])dx-=1;
  if(keys['d']||keys['ArrowRight'])dx+=1;
  if(dx||dy){const l=Math.hypot(dx,dy);player.x+=dx/l*player.speed*(dt/16);player.y+=dy/l*player.speed*(dt/16)}
  player.x=Math.max(20,Math.min(world.w-20,player.x));player.y=Math.max(20,Math.min(world.h-20,player.y));

  const camX=Math.max(0,Math.min(world.w-innerWidth,player.x-innerWidth/2));
  const camY=Math.max(0,Math.min(world.h-innerHeight,player.y-innerHeight/2));
  drawWorld(camX,camY);

  document.getElementById('level').textContent=state.level;
  document.getElementById('hp').textContent=state.hp;
  document.getElementById('gold').textContent=state.gold;
  document.getElementById('wood').textContent=state.wood;
  document.getElementById('stone').textContent=state.stone;
  document.getElementById('copper').textContent=state.copper;
  document.getElementById('iron').textContent=state.iron;
  document.getElementById('fish').textContent=state.fish;
  requestAnimationFrame(update);
}
msg('Muévete con WASD, flechas o los botones táctiles. Pulsa E/ESPACIO cerca de un recurso o monstruo.');
requestAnimationFrame(update);
